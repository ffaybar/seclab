# PenTest+ Lab Deployment

This repo contains an Ansible playbook and support files to automate your PenTest+ lab setup using Kali Linux. Built and maintained by ffaybar.