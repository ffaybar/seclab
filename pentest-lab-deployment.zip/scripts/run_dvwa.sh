#!/bin/bash
sudo docker run -d -p 8080:80 vulnerables/web-dvwa
