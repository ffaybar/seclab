#!/bin/bash
sudo docker run -d -p 3000:3000 bkimminich/juice-shop
