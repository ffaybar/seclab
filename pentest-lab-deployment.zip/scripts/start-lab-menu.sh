#!/bin/bash
while true; do
  echo "Select a target to launch:"
  echo "1) DVWA"
  echo "2) Juice Shop"
  echo "3) Quit"
  read -rp "Choice: " choice
  case $choice in
    1) bash ~/scripts/run_dvwa.sh ;;
    2) bash ~/scripts/run_juiceshop.sh ;;
    3) echo "Exiting..." ; exit 0 ;;
    *) echo "Invalid option" ;;
  esac
done
