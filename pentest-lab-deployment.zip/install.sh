#!/bin/bash
echo "[*] Installing dependencies..."
sudo apt update && sudo apt install -y ansible git

echo "[*] Cloning PenTest Lab repository..."
git clone https://github.com/ffaybar/pentest-lab-deployment.git ~/pentest-lab-deployment

cd ~/pentest-lab-deployment/playbooks

echo "[*] Running Ansible playbook..."
ansible-playbook attackbox_setup.yaml --connection=local

echo "[✓] Done! Start your lab using:"
echo "bash ~/scripts/start-lab-menu.sh"
